import "dotenv/config";
import fs from "node:fs";

const keys = [
  "OPENAI_API_KEY",
  "OPENAI_PROJECT_ID",
  "OPENAI_WEBHOOK_SECRET",
  "ADMIN_TOKEN",
  "OPENAI_REALTIME_MODEL",
  "OPENAI_REALTIME_VOICE",
  "BUSINESS_PUBLIC_PHONE",
  "DIDWW_API_KEY",
  "DIDWW_DID_NUMBER",
  "MULTIGESTIONALE_USER_API",
  "MULTIGESTIONALE_ENGINE",
  "GOOGLE_CALENDAR_ID",
  "GOOGLE_AUTH_MODE",
  "GOOGLE_OAUTH_CLIENT_ID",
  "GOOGLE_OAUTH_CLIENT_SECRET",
  "GOOGLE_OAUTH_REFRESH_TOKEN",
  "BUSINESS_TIMEZONE",
  "BUSINESS_OPEN_HOUR",
  "BUSINESS_CLOSE_HOUR",
  "APPOINTMENT_DURATION_MINUTES",
  "APPOINTMENT_MIN_NOTICE_HOURS",
  "APPOINTMENT_SLOT_MINUTES",
  "LOCATION_URL"
];

const lines = keys
  .filter((key) => process.env[key])
  .map((key) => `${key}=${process.env[key]}`);

fs.writeFileSync(".env.production.values", `${lines.join("\n")}\n`);
console.log(`Scritte ${lines.length} variabili in .env.production.values`);
